const Scan = require('../models/scan');
const axios = require('axios');
const https = require('https');
const dns = require('dns').promises;

// Cache for reputation checks
const reputationCache = new Map();
const CACHE_DURATION = 3600000;

// === Machine Learning Model ===
const MLModel = {
  weights: {
    httpsWeight: 0.15, ipAddressWeight: 0.20, lengthWeight: 0.08,
    subdomainWeight: 0.12, keywordWeight: 0.18, brandWeight: 0.25,
    tldWeight: 0.10, ageWeight: 0.15, sslWeight: 0.20
  },
  
  predict: function(features) {
    let score = 0;
    score += features.hasHttps ? 0 : this.weights.httpsWeight * 100;
    score += features.isIpAddress ? this.weights.ipAddressWeight * 100 : 0;
    score += features.isLongUrl ? this.weights.lengthWeight * 100 : 0;
    score += features.excessiveSubdomains ? this.weights.subdomainWeight * 100 : 0;
    score += features.phishingKeywords * this.weights.keywordWeight * 10;
    score += features.brandImpersonation ? this.weights.brandWeight * 100 : 0;
    score += features.suspiciousTld ? this.weights.tldWeight * 100 : 0;
    score += features.newDomain ? this.weights.ageWeight * 50 : 0;
    score += features.invalidSsl ? this.weights.sslWeight * 100 : 0;
    return Math.min(score, 100);
  }
};

// === FEATURE 1: Google Safe Browsing ===
const checkGoogleSafeBrowsing = async (url) => {
  try {
    const apiKey = process.env.GOOGLE_SAFE_BROWSING_API_KEY;
    if (!apiKey) return { isSafe: true, threats: [] };

    const response = await axios.post(
      `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${apiKey}`,
      {
        client: { clientId: "fraudguard", clientVersion: "1.0.0" },
        threatInfo: {
          threatTypes: ["MALWARE", "SOCIAL_ENGINEERING"],
          platformTypes: ["ANY_PLATFORM"],
          threatEntryTypes: ["URL"],
          threatEntries: [{ url }]
        }
      },
      { timeout: 5000 }
    );

    const matches = response.data.matches || [];
    return { isSafe: matches.length === 0, threats: matches.map(m => m.threatType) };
  } catch {
    return { isSafe: true, threats: [] };
  }
};

// === FEATURE 2: SSL Certificate Validation ===
const validateSSL = async (hostname) => {
  return new Promise((resolve) => {
    try {
      const req = https.request({
        host: hostname, port: 443, method: 'GET', rejectUnauthorized: true
      }, (res) => {
        const cert = res.socket.getPeerCertificate();
        if (!cert || !Object.keys(cert).length) {
          resolve({ valid: false, reason: 'No certificate' });
          return;
        }
        const now = new Date();
        const validTo = new Date(cert.valid_to);
        if (now > validTo) {
          resolve({ valid: false, reason: 'Expired' });
        } else {
          resolve({ valid: true, issuer: cert.issuer.O || 'Unknown', validTo });
        }
      });
      req.on('error', () => resolve({ valid: false, reason: 'Failed' }));
      req.setTimeout(5000, () => { req.destroy(); resolve({ valid: false, reason: 'Timeout' }); });
      req.end();
    } catch {
      resolve({ valid: false, reason: 'Error' });
    }
  });
};

// === FEATURE 3: Domain Age ===
const checkDomainAge = async (hostname) => {
  try {
    await dns.resolve4(hostname);
    const newTlds = ['.tk', '.ml', '.ga', '.cf', '.gq', '.xyz'];
    const isNew = newTlds.some(t => hostname.endsWith(t));
    return { age: isNew ? 30 : 365, isNew };
  } catch {
    return { age: 0, isNew: true };
  }
};

// === FEATURE 4: Reputation Database ===
const checkReputation = async (hostname) => {
  const cached = reputationCache.get(hostname);
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.data;
  }

  let score = 50;
  const trusted = ['google.com', 'facebook.com', 'amazon.com', 'microsoft.com'];
  if (trusted.some(d => hostname.endsWith(d))) score = 95;
  
  const badTlds = ['.tk', '.ml', '.ga'];
  if (badTlds.some(t => hostname.endsWith(t))) score -= 30;

  const rep = { score };
  reputationCache.set(hostname, { data: rep, timestamp: Date.now() });
  return rep;
};

// === FEATURE 5: Blacklist Check ===
const checkBlacklists = (url) => {
  const patterns = [/password.*reset/i, /account.*suspend/i, /verify.*identity/i];
  if (patterns.some(p => p.test(url))) {
    return [{ source: 'Pattern Analysis', reason: 'Phishing pattern', severity: 'High' }];
  }
  return [];
};

// === FEATURE 6: Content Analysis ===
const analyzeContent = async (url) => {
  try {
    const response = await axios.get(url, {
      timeout: 5000, maxRedirects: 3,
      headers: { 'User-Agent': 'FraudGuard/1.0' }
    });

    const html = response.data.toLowerCase();
    const suspicious = [];

    if (html.includes('type="hidden"') && html.includes('password')) {
      suspicious.push('Hidden password fields');
    }
    if (html.includes('eval(')) suspicious.push('Suspicious JS');
    
    const phrases = ['verify account', 'suspended', 'urgent'];
    const found = phrases.filter(p => html.includes(p));
    if (found.length) suspicious.push(`Phishing: ${found.join(', ')}`);

    return { analyzed: true, suspiciousElements: suspicious };
  } catch {
    return { analyzed: false, suspiciousElements: [] };
  }
};

// === Main Analysis ===
const analyzeURL = async (url) => {
  let riskScore = 0;
  const threats = [];
  const mlFeatures = {
    hasHttps: false, isIpAddress: false, isLongUrl: false,
    excessiveSubdomains: false, phishingKeywords: 0,
    brandImpersonation: false, suspiciousTld: false,
    newDomain: false, invalidSsl: false
  };

  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname;

    // Google Safe Browsing
    const safeBrowsing = await checkGoogleSafeBrowsing(url);
    if (!safeBrowsing.isSafe) {
      riskScore += 50;
      threats.push({
        type: 'Google Safe Browsing Alert',
        severity: 'Critical',
        description: `Threats: ${safeBrowsing.threats.join(', ')}`
      });
    }

    // SSL Validation
    if (urlObj.protocol === 'https:') {
      mlFeatures.hasHttps = true;
      const ssl = await validateSSL(hostname);
      if (!ssl.valid) {
        riskScore += 30;
        mlFeatures.invalidSsl = true;
        threats.push({ type: 'Invalid SSL', severity: 'High', description: ssl.reason });
      }
    }

    // Domain Age
    const age = await checkDomainAge(hostname);
    if (age.isNew) {
      riskScore += 25;
      mlFeatures.newDomain = true;
      threats.push({ type: 'New Domain', severity: 'Medium', description: `${age.age} days old` });
    }

    // Reputation
    const rep = await checkReputation(hostname);
    if (rep.score < 40) {
      riskScore += 20;
      threats.push({ type: 'Poor Reputation', severity: 'Medium', description: `Score: ${rep.score}/100` });
    } else if (rep.score > 80) {
      riskScore -= 10;
    }

    // Blacklist
    const blacklists = checkBlacklists(url);
    if (blacklists.length) {
      riskScore += 40;
      blacklists.forEach(bl => {
        threats.push({ type: `Blacklisted - ${bl.source}`, severity: bl.severity, description: bl.reason });
      });
    }

    // Content Analysis
    const content = await analyzeContent(url);
    if (content.analyzed && content.suspiciousElements.length) {
      riskScore += content.suspiciousElements.length * 10;
      threats.push({
        type: 'Suspicious Content',
        severity: content.suspiciousElements.length > 2 ? 'High' : 'Medium',
        description: content.suspiciousElements.join('; ')
      });
    }

    // Heuristics
    if (urlObj.protocol !== 'https:') {
      riskScore += 20;
      threats.push({ type: 'No HTTPS', severity: 'Medium', description: 'Unencrypted' });
    }

    if ((url.includes('login') || url.includes('account')) && urlObj.protocol !== 'https:') {
      riskScore += 30;
      threats.push({ type: 'Insecure Login', severity: 'High', description: 'Login without HTTPS' });
    }

    if (/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(hostname)) {
      riskScore += 25;
      mlFeatures.isIpAddress = true;
      threats.push({ type: 'IP Address', severity: 'Medium', description: 'Using IP not domain' });
    }

    if (url.length > 75) {
      riskScore += 15;
      mlFeatures.isLongUrl = true;
      threats.push({ type: 'Long URL', severity: 'Low', description: `${url.length} chars` });
    }

    if (hostname.split('.').length > 4) {
      riskScore += 20;
      mlFeatures.excessiveSubdomains = true;
      threats.push({ type: 'Many Subdomains', severity: 'Medium', description: 'Excessive subdomains' });
    }

    const keywords = ['verify', 'account', 'update', 'urgent', 'suspend'];
    const found = keywords.filter(k => url.toLowerCase().includes(k));
    if (found.length) {
      riskScore += found.length * 10;
      mlFeatures.phishingKeywords = found.length;
      threats.push({
        type: 'Phishing Keywords',
        severity: found.length > 2 ? 'High' : 'Medium',
        description: found.join(', ')
      });
    }

    const brands = ['paypal', 'amazon', 'google', 'microsoft'];
    const fake = brands.find(b => hostname.includes(b) && !hostname.endsWith(`${b}.com`));
    if (fake) {
      riskScore += 35;
      mlFeatures.brandImpersonation = true;
      threats.push({ type: 'Brand Impersonation', severity: 'Critical', description: `Fake ${fake}` });
    }

    const badTlds = ['.tk', '.ml', '.ga', '.cf', '.gq'];
    const tld = hostname.substring(hostname.lastIndexOf('.'));
    if (badTlds.includes(tld)) {
      riskScore += 15;
      mlFeatures.suspiciousTld = true;
      threats.push({ type: 'Bad TLD', severity: 'Low', description: `${tld} spam TLD` });
    }

    // ML Prediction
    const mlScore = MLModel.predict(mlFeatures);
    riskScore = (riskScore * 0.7) + (mlScore * 0.3);

  } catch {
    riskScore += 40;
    threats.push({ type: 'Invalid URL', severity: 'High', description: 'Malformed' });
  }

  let riskLevel;
  if (riskScore >= 70) riskLevel = 'Critical';
  else if (riskScore >= 50) riskLevel = 'High';
  else if (riskScore >= 30) riskLevel = 'Medium';
  else riskLevel = 'Low';

  return { riskScore: Math.min(Math.max(Math.round(riskScore), 0), 100), riskLevel, threats };
};

exports.scanURL = async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: 'URL required' });

    const analysis = await analyzeURL(url.trim());
    const scan = await Scan.create({ userId: req.userId, url: url.trim(), ...analysis });

    res.status(201).json({ success: true, scan });
  } catch (error) {
    res.status(500).json({ error: 'Scan failed', message: error.message });
  }
};

exports.getScanHistory = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    const page = parseInt(req.query.page) || 1;
    const scans = await Scan.find({ userId: req.userId })
      .sort({ scanDate: -1 })
      .limit(limit)
      .skip((page - 1) * limit);
    const total = await Scan.countDocuments({ userId: req.userId });
    res.json({ success: true, scans, pagination: { total, page, pages: Math.ceil(total / limit), limit } });
  } catch {
    res.status(500).json({ error: 'Failed' });
  }
};

exports.getScanStats = async (req, res) => {
  try {
    const stats = await Scan.aggregate([
      { $match: { userId: req.userId } },
      { $group: { _id: '$riskLevel', count: { $sum: 1 } } }
    ]);
    const total = await Scan.countDocuments({ userId: req.userId });
    res.json({
      success: true,
      stats: { total, byRiskLevel: stats.reduce((acc, curr) => ({ ...acc, [curr._id]: curr.count }), {}) }
    });
  } catch {
    res.status(500).json({ error: 'Failed' });
  }
};
