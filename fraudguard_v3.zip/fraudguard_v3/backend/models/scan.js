const mongoose = require('mongoose');

const scanSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  url: {
    type: String,
    required: [true, 'URL is required'],
    trim: true
  },
  riskScore: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  riskLevel: {
    type: String,
    enum: ['Low', 'Medium', 'High', 'Critical'],
    required: true
  },
  threats: [{
    type: {
      type: String,
      required: true
    },
    severity: {
      type: String,
      enum: ['Low', 'Medium', 'High', 'Critical'],
      required: true
    },
    description: {
      type: String,
      required: true
    }
  }],
  scanDate: {
    type: Date,
    default: Date.now
  }
});

// Index for faster queries
scanSchema.index({ userId: 1, scanDate: -1 });

module.exports = mongoose.model('Scan', scanSchema);
