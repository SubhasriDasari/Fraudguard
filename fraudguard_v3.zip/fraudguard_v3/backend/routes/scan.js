const express = require('express');
const auth = require('../middleware/auth');
const { scanURL, getScanHistory, getScanStats } = require('../controllers/frauddetection');

const router = express.Router();

// All routes require authentication
router.post('/scan', auth, scanURL);
router.get('/history', auth, getScanHistory);
router.get('/stats', auth, getScanStats);

module.exports = router;
