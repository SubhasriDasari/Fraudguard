import { Link } from 'react-router-dom'
import { useState, useEffect, useRef } from 'react'
import {
  Shield, Search, Lock, Zap, Globe, AlertTriangle, CheckCircle,
  ArrowRight, Eye, Activity, BarChart2, Cpu, Database, Star,
  ChevronDown, Menu, X
} from 'lucide-react'

// Animated counter hook
function useCounter(target, duration = 2000) {
  const [count, setCount] = useState(0)
  const [started, setStarted] = useState(false)
  useEffect(() => {
    if (!started) return
    let start = 0
    const step = target / (duration / 16)
    const timer = setInterval(() => {
      start += step
      if (start >= target) { setCount(target); clearInterval(timer) }
      else setCount(Math.floor(start))
    }, 16)
    return () => clearInterval(timer)
  }, [started, target, duration])
  return [count, setStarted]
}

// Floating particle SVG
function ParticleField() {
  return (
    <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
      {[...Array(20)].map((_, i) => (
        <circle key={i}
          cx={`${5 + (i * 4.7) % 95}%`}
          cy={`${10 + (i * 7.3) % 80}%`}
          r={1 + (i % 3)}
          fill={i % 3 === 0 ? '#3b82f6' : i % 3 === 1 ? '#8b5cf6' : '#06b6d4'}
          opacity={0.3 + (i % 5) * 0.1}
          style={{ animation: `float ${3 + (i % 4)}s ease-in-out infinite`, animationDelay: `${i * 0.3}s` }}
        />
      ))}
    </svg>
  )
}

// Shield SVG Illustration
function ShieldIllustration() {
  return (
    <div className="relative w-72 h-72 mx-auto">
      <svg viewBox="0 0 300 300" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
        {/* Outer glow rings */}
        <circle cx="150" cy="150" r="130" fill="none" stroke="#3b82f6" strokeWidth="0.5" opacity="0.3" style={{animation:'pulse 3s ease-in-out infinite'}}/>
        <circle cx="150" cy="150" r="110" fill="none" stroke="#8b5cf6" strokeWidth="0.5" opacity="0.4" style={{animation:'pulse 3s ease-in-out infinite', animationDelay:'0.5s'}}/>
        <circle cx="150" cy="150" r="90" fill="none" stroke="#06b6d4" strokeWidth="1" opacity="0.5" style={{animation:'pulse 3s ease-in-out infinite', animationDelay:'1s'}}/>
        {/* Shield body */}
        <defs>
          <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1d4ed8"/>
            <stop offset="50%" stopColor="#7c3aed"/>
            <stop offset="100%" stopColor="#0891b2"/>
          </linearGradient>
          <linearGradient id="innerGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.2"/>
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.1"/>
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        </defs>
        <path d="M150 40 L220 70 L220 150 Q220 210 150 250 Q80 210 80 150 L80 70 Z"
          fill="url(#shieldGrad)" filter="url(#glow)" opacity="0.9"/>
        <path d="M150 55 L210 80 L210 150 Q210 200 150 235 Q90 200 90 150 L90 80 Z"
          fill="url(#innerGrad)" stroke="rgba(255,255,255,0.2)" strokeWidth="1"/>
        {/* Checkmark */}
        <path d="M120 150 L140 170 L185 120" stroke="white" strokeWidth="6"
          strokeLinecap="round" strokeLinejoin="round" fill="none" filter="url(#glow)"/>
        {/* Scan lines */}
        {[0,1,2].map(i => (
          <line key={i} x1="100" y1={130+i*15} x2="200" y2={130+i*15}
            stroke="rgba(255,255,255,0.1)" strokeWidth="1"
            style={{animation:`scan 2s ease-in-out infinite`, animationDelay:`${i*0.3}s`}}/>
        ))}
      </svg>
    </div>
  )
}

// Threat Chart Illustration
function ThreatChartIllustration() {
  const bars = [65, 40, 85, 30, 70, 50, 90]
  const colors = ['#ef4444','#f97316','#ef4444','#22c55e','#f97316','#22c55e','#ef4444']
  return (
    <svg viewBox="0 0 280 160" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        {colors.map((c,i) => (
          <linearGradient key={i} id={`barGrad${i}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={c} stopOpacity="0.9"/>
            <stop offset="100%" stopColor={c} stopOpacity="0.3"/>
          </linearGradient>
        ))}
      </defs>
      {/* Grid lines */}
      {[0,1,2,3].map(i => (
        <line key={i} x1="20" y1={20+i*30} x2="270" y2={20+i*30}
          stroke="rgba(255,255,255,0.05)" strokeWidth="1"/>
      ))}
      {/* Bars */}
      {bars.map((h, i) => (
        <rect key={i} x={25+i*35} y={140-h*1.1} width="22" height={h*1.1}
          fill={`url(#barGrad${i})`} rx="3"
          style={{animation:`growUp 1s ease-out forwards`, animationDelay:`${i*0.1}s`}}/>
      ))}
      {/* Labels */}
      {['M','T','W','T','F','S','S'].map((d,i) => (
        <text key={i} x={36+i*35} y="155" textAnchor="middle"
          fill="rgba(255,255,255,0.4)" fontSize="10">{d}</text>
      ))}
      <text x="20" y="15" fill="rgba(255,255,255,0.6)" fontSize="11">Threats This Week</text>
    </svg>
  )
}

// Scan Animation
function ScanAnimation() {
  return (
    <div className="relative bg-gray-900 rounded-xl p-4 font-mono text-xs overflow-hidden border border-gray-700">
      <div className="absolute inset-0 bg-gradient-to-b from-green-500/5 to-transparent pointer-events-none"/>
      {/* Scan line */}
      <div className="absolute left-0 right-0 h-px bg-green-400/40" style={{top:'30%', animation:'scanLine 2s linear infinite'}}/>
      <div className="text-green-400 mb-2 flex items-center gap-2">
        <span className="animate-pulse">●</span> SCANNING URL...
      </div>
      {[
        {label:'HTTPS', val:'FAIL', color:'text-red-400'},
        {label:'SSL CERT', val:'INVALID', color:'text-red-400'},
        {label:'DOMAIN AGE', val:'32 days', color:'text-yellow-400'},
        {label:'BLACKLIST', val:'MATCH', color:'text-red-400'},
        {label:'ML MODEL', val:'HIGH RISK', color:'text-orange-400'},
        {label:'REPUTATION', val:'24/100', color:'text-red-400'},
      ].map((item, i) => (
        <div key={i} className="flex justify-between py-0.5 border-b border-gray-800" style={{animationDelay:`${i*0.2}s`}}>
          <span className="text-gray-500">{item.label}</span>
          <span className={item.color}>{item.val}</span>
        </div>
      ))}
      <div className="mt-2 flex items-center gap-2">
        <div className="flex-1 bg-gray-800 rounded-full h-2">
          <div className="h-2 rounded-full bg-gradient-to-r from-red-600 to-orange-500" style={{width:'85%'}}/>
        </div>
        <span className="text-red-400 font-bold">85/100</span>
      </div>
      <div className="mt-1 text-red-400 font-bold text-center">⚠ CRITICAL THREAT DETECTED</div>
    </div>
  )
}

// DNA Helix / Network lines SVG
function NetworkBackground() {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-5" xmlns="http://www.w3.org/2000/svg">
      {[...Array(8)].map((_, i) => (
        <line key={i}
          x1={`${i*14}%`} y1="0" x2={`${100-i*14}%`} y2="100%"
          stroke="url(#lineGrad)" strokeWidth="1"/>
      ))}
      <defs>
        <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3b82f6"/>
          <stop offset="100%" stopColor="#8b5cf6"/>
        </linearGradient>
      </defs>
    </svg>
  )
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const statsRef = useRef(null)
  const [statsVisible, setStatsVisible] = useState(false)

  const [scansCount, startScans] = useCounter(128450, 2000)
  const [threatsCount, startThreats] = useCounter(47832, 2000)
  const [accuracy, startAccuracy] = useCounter(99, 1500)
  const [users, startUsers] = useCounter(12400, 2000)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !statsVisible) {
        setStatsVisible(true)
        startScans(true); startThreats(true)
        startAccuracy(true); startUsers(true)
      }
    }, { threshold: 0.3 })
    if (statsRef.current) obs.observe(statsRef.current)
    return () => obs.disconnect()
  }, [statsVisible])

  const features = [
    { icon: <Shield className="w-6 h-6"/>, title: 'Google Safe Browsing', desc: "Google's real-time threat database", color: 'from-blue-500 to-blue-700', bg: 'bg-blue-500/10 border-blue-500/20' },
    { icon: <Lock className="w-6 h-6"/>, title: 'SSL Validation', desc: 'Deep certificate analysis & expiry checks', color: 'from-violet-500 to-violet-700', bg: 'bg-violet-500/10 border-violet-500/20' },
    { icon: <Activity className="w-6 h-6"/>, title: 'Domain Age Check', desc: 'Detect newly registered suspicious domains', color: 'from-cyan-500 to-cyan-700', bg: 'bg-cyan-500/10 border-cyan-500/20' },
    { icon: <Database className="w-6 h-6"/>, title: 'Reputation Database', desc: 'Multi-source domain trust scoring', color: 'from-emerald-500 to-emerald-700', bg: 'bg-emerald-500/10 border-emerald-500/20' },
    { icon: <Eye className="w-6 h-6"/>, title: 'Content Analysis', desc: 'Live webpage scanning for phishing content', color: 'from-orange-500 to-orange-700', bg: 'bg-orange-500/10 border-orange-500/20' },
    { icon: <Cpu className="w-6 h-6"/>, title: 'ML Model', desc: 'AI-powered risk prediction engine', color: 'from-pink-500 to-pink-700', bg: 'bg-pink-500/10 border-pink-500/20' },
    { icon: <BarChart2 className="w-6 h-6"/>, title: 'Risk Analytics', desc: 'Visual data charts & threat breakdowns', color: 'from-amber-500 to-amber-700', bg: 'bg-amber-500/10 border-amber-500/20' },
    { icon: <Zap className="w-6 h-6"/>, title: 'Instant Results', desc: 'Comprehensive scan in under 5 seconds', color: 'from-rose-500 to-rose-700', bg: 'bg-rose-500/10 border-rose-500/20' },
  ]

  const testimonials = [
    { name: 'Arjun Sharma', role: 'Security Analyst', text: 'FraudGuard caught a phishing attempt targeting my company before any damage was done. The ML model is impressive!', rating: 5 },
    { name: 'Priya Nair', role: 'IT Manager', text: 'The visual risk dashboards make it incredibly easy to explain threats to non-technical stakeholders.', rating: 5 },
    { name: 'Rahul Verma', role: 'Student', text: 'Used this to verify suspicious links I received. Simple, fast, and surprisingly accurate!', rating: 4 },
  ]

  return (
    <div className="min-h-screen bg-[#050a18] text-white overflow-x-hidden">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=Inter:wght@300;400;500;600&display=swap');
        * { font-family: 'Inter', sans-serif; }
        h1,h2,h3,.font-display { font-family: 'Syne', sans-serif; }
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }
        @keyframes scanLine { 0%{top:0%} 100%{top:100%} }
        @keyframes growUp { from{transform:scaleY(0);transform-origin:bottom} to{transform:scaleY(1)} }
        @keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }
        @keyframes orbit { from{transform:rotate(0deg) translateX(120px) rotate(0deg)} to{transform:rotate(360deg) translateX(120px) rotate(-360deg)} }
        @keyframes fadeSlideUp { from{opacity:0;transform:translateY(30px)} to{opacity:1;transform:translateY(0)} }
        .shimmer-text { background: linear-gradient(90deg, #60a5fa, #a78bfa, #60a5fa); background-size:200% auto; -webkit-background-clip:text; -webkit-text-fill-color:transparent; animation: shimmer 3s linear infinite; }
        .card-glow { transition: all 0.3s ease; }
        .card-glow:hover { transform: translateY(-4px); box-shadow: 0 20px 40px rgba(59,130,246,0.2); }
        .hero-animate { animation: fadeSlideUp 0.8s ease forwards; opacity: 0; }
      `}</style>

      {/* NAV */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-[#050a18]/90 backdrop-blur-xl border-b border-white/5 py-3' : 'py-5'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-white"/>
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-[#050a18] animate-pulse"/>
            </div>
            <span className="font-display font-bold text-xl tracking-tight">FraudGuard</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {['Features','How It Works','Use Cases'].map(item => (
              <a key={item} href={`#${item.toLowerCase().replace(' ','-')}`}
                className="text-sm text-gray-400 hover:text-white transition-colors">{item}</a>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            <Link to="/login" className="text-sm text-gray-400 hover:text-white px-4 py-2 transition-colors">Login</Link>
            <Link to="/signup" className="text-sm bg-gradient-to-r from-blue-600 to-violet-600 px-5 py-2 rounded-lg font-medium hover:opacity-90 transition-opacity">
              Get Started →
            </Link>
          </div>

          <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X className="w-6 h-6"/> : <Menu className="w-6 h-6"/>}
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden bg-[#0d1526] border-t border-white/5 px-6 py-4 space-y-3">
            {['Features','How It Works'].map(item => (
              <a key={item} href="#" className="block text-gray-400 hover:text-white py-1">{item}</a>
            ))}
            <Link to="/login" className="block text-gray-400 py-1">Login</Link>
            <Link to="/signup" className="block bg-blue-600 text-white text-center py-2 rounded-lg">Get Started</Link>
          </div>
        )}
      </nav>

      {/* HERO */}
      <section className="relative min-h-screen flex items-center pt-24 pb-16 overflow-hidden">
        <NetworkBackground/>
        <ParticleField/>

        {/* Glow orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[100px] pointer-events-none"/>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-violet-600/10 rounded-full blur-[100px] pointer-events-none"/>

        <div className="max-w-7xl mx-auto px-6 w-full grid lg:grid-cols-2 gap-16 items-center">
          {/* Left */}
          <div>
            <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-1.5 mb-8 hero-animate" style={{animationDelay:'0.1s'}}>
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"/>
              <span className="text-sm text-blue-300">AI-Powered Security Scanner</span>
            </div>

            <h1 className="font-display text-5xl lg:text-7xl font-bold leading-[1.05] mb-6 hero-animate" style={{animationDelay:'0.2s'}}>
              Stop Fraud
              <span className="block shimmer-text">Before It</span>
              <span className="block">Stops You</span>
            </h1>

            <p className="text-gray-400 text-lg leading-relaxed mb-10 max-w-lg hero-animate" style={{animationDelay:'0.3s'}}>
              Military-grade URL threat detection powered by Google Safe Browsing, 
              Machine Learning, SSL validation, and real-time blacklist checking.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 hero-animate" style={{animationDelay:'0.4s'}}>
              <Link to="/signup" className="flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-violet-600 px-8 py-4 rounded-xl font-semibold hover:opacity-90 transition-opacity text-lg">
                Start Scanning Free <ArrowRight className="w-5 h-5"/>
              </Link>
              <a href="#features" className="flex items-center justify-center gap-2 border border-white/10 bg-white/5 px-8 py-4 rounded-xl font-medium hover:bg-white/10 transition-colors text-lg">
                See Features
              </a>
            </div>

            <div className="grid grid-cols-3 gap-4 mt-12 hero-animate" style={{animationDelay:'0.5s'}}>
              {[
                {val:'7+', label:'Detection Layers'},
                {val:'<5s', label:'Scan Time'},
                {val:'95%+', label:'Accuracy'},
              ].map((s,i) => (
                <div key={i} className="border border-white/5 bg-white/3 rounded-xl p-4 text-center">
                  <div className="font-display text-2xl font-bold text-blue-400">{s.val}</div>
                  <div className="text-xs text-gray-500 mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right — Shield + floating cards */}
          <div className="relative flex items-center justify-center hero-animate" style={{animationDelay:'0.4s'}}>
            <ShieldIllustration/>

            {/* Floating info cards */}
            <div className="absolute top-4 right-0 bg-[#0d1526] border border-red-500/30 rounded-xl p-3 text-sm w-44 shadow-xl shadow-red-900/10"
              style={{animation:'float 4s ease-in-out infinite'}}>
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className="w-4 h-4 text-red-400"/>
                <span className="text-red-400 font-semibold text-xs">Threat Detected</span>
              </div>
              <div className="text-gray-400 text-xs">Brand impersonation + Invalid SSL</div>
              <div className="mt-2 text-red-400 font-bold">Risk: 92/100</div>
            </div>

            <div className="absolute bottom-8 left-0 bg-[#0d1526] border border-green-500/30 rounded-xl p-3 text-sm w-44 shadow-xl shadow-green-900/10"
              style={{animation:'float 4s ease-in-out infinite', animationDelay:'1s'}}>
              <div className="flex items-center gap-2 mb-1">
                <CheckCircle className="w-4 h-4 text-green-400"/>
                <span className="text-green-400 font-semibold text-xs">Safe URL</span>
              </div>
              <div className="text-gray-400 text-xs">Valid SSL · Trusted domain</div>
              <div className="mt-2 text-green-400 font-bold">Risk: 3/100</div>
            </div>

            <div className="absolute top-1/2 -left-4 bg-[#0d1526] border border-blue-500/30 rounded-xl p-3 text-xs w-36 shadow-xl"
              style={{animation:'float 5s ease-in-out infinite', animationDelay:'0.5s'}}>
              <div className="text-blue-400 font-semibold mb-1">ML Analysis</div>
              <div className="space-y-1">
                <div className="flex justify-between text-gray-500">
                  <span>Phishing</span><span className="text-orange-400">High</span>
                </div>
                <div className="flex justify-between text-gray-500">
                  <span>Malware</span><span className="text-green-400">Low</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-6 h-6 text-gray-600"/>
        </div>
      </section>

      {/* LIVE STATS */}
      <section ref={statsRef} className="py-16 border-y border-white/5 bg-[#080e1e]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              {val: scansCount.toLocaleString(), label:'URLs Scanned', color:'text-blue-400'},
              {val: threatsCount.toLocaleString(), label:'Threats Blocked', color:'text-red-400'},
              {val: `${accuracy}%`, label:'Detection Accuracy', color:'text-green-400'},
              {val: users.toLocaleString(), label:'Active Users', color:'text-violet-400'},
            ].map((s,i) => (
              <div key={i} className="text-center">
                <div className={`font-display text-4xl font-bold ${s.color}`}>{s.val}</div>
                <div className="text-gray-500 text-sm mt-2">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES GRID */}
      <section id="features" className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-[#080e1e] to-[#050a18] pointer-events-none"/>
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-violet-500/10 border border-violet-500/20 rounded-full px-4 py-1.5 mb-4">
              <span className="text-violet-400 text-sm">7 Detection Layers</span>
            </div>
            <h2 className="font-display text-4xl lg:text-5xl font-bold mb-4">
              Enterprise-Grade
              <span className="shimmer-text block">Security Features</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Every scan runs through 7 independent detection systems simultaneously, giving you the most comprehensive URL analysis available.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((f, i) => (
              <div key={i} className={`card-glow border ${f.bg} rounded-2xl p-6 cursor-default`}>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-4`}>
                  {f.icon}
                </div>
                <h3 className="font-display font-bold text-base mb-2">{f.title}</h3>
                <p className="text-gray-500 text-sm">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS + VISUALISATION */}
      <section id="how-it-works" className="py-24 bg-[#080e1e]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl lg:text-5xl font-bold mb-4">How It Works</h2>
            <p className="text-gray-400 max-w-xl mx-auto">See our scanner in action with real-time analysis</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Steps */}
            <div className="space-y-8">
              {[
                { step:'01', title:'Enter the URL', desc:'Paste any suspicious link into the scanner. Supports HTTP, HTTPS, and shortened URLs.', color:'blue' },
                { step:'02', title:'Multi-Layer Analysis', desc:'7 detection systems run simultaneously — Google Safe Browsing, SSL, ML model, blacklists, domain age, reputation, and content.', color:'violet' },
                { step:'03', title:'AI Risk Score', desc:'Our ML model combines all signals to generate a precise 0-100 risk score with detailed threat breakdown.', color:'cyan' },
                { step:'04', title:'Visual Report', desc:'View interactive charts, threat categories, and actionable recommendations — all in one dashboard.', color:'emerald' },
              ].map((s, i) => (
                <div key={i} className="flex gap-6">
                  <div className={`w-12 h-12 rounded-xl bg-${s.color}-500/10 border border-${s.color}-500/20 flex items-center justify-center flex-shrink-0`}>
                    <span className={`font-display font-bold text-${s.color}-400 text-sm`}>{s.step}</span>
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-lg mb-1">{s.title}</h3>
                    <p className="text-gray-500 text-sm leading-relaxed">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Live scan demo */}
            <div className="space-y-4">
              <ScanAnimation/>
              <div className="bg-[#0d1526] border border-white/5 rounded-xl p-4">
                <ThreatChartIllustration/>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* USE CASES */}
      <section id="use-cases" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl lg:text-5xl font-bold mb-4">Who Uses FraudGuard?</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                title:'Individuals',
                icon:'👤',
                desc:'Verify suspicious links from emails, messages, and social media before clicking.',
                points:['Email phishing protection','Social media link safety','Online shopping verification']
              },
              {
                title:'Businesses',
                icon:'🏢',
                desc:"Protect your organization from cyber attacks and data breaches.",
                points:['Employee security training','Vendor link verification','Incident response']
              },
              {
                title:'Security Teams',
                icon:'🛡️',
                desc:'Advanced threat intelligence for security researchers and analysts.',
                points:['Threat investigation','Malware analysis','Risk reporting']
              },
            ].map((u,i) => (
              <div key={i} className="card-glow bg-[#0d1526] border border-white/5 rounded-2xl p-8">
                <div className="text-4xl mb-4">{u.icon}</div>
                <h3 className="font-display text-xl font-bold mb-3">{u.title}</h3>
                <p className="text-gray-400 text-sm mb-6">{u.desc}</p>
                <ul className="space-y-2">
                  {u.points.map((p,j) => (
                    <li key={j} className="flex items-center gap-2 text-sm text-gray-400">
                      <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0"/>
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-24 bg-[#080e1e]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl font-bold mb-4">What People Say</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t,i) => (
              <div key={i} className="card-glow bg-[#0d1526] border border-white/5 rounded-2xl p-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(t.rating)].map((_,j) => <Star key={j} className="w-4 h-4 text-amber-400 fill-amber-400"/>)}
                </div>
                <p className="text-gray-400 text-sm leading-relaxed mb-6">"{t.text}"</p>
                <div>
                  <div className="font-semibold text-sm">{t.name}</div>
                  <div className="text-gray-500 text-xs">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 to-violet-900/20 pointer-events-none"/>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-full bg-gradient-to-b from-transparent via-blue-500/20 to-transparent pointer-events-none"/>
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-8">
            <Shield className="w-10 h-10 text-white"/>
          </div>
          <h2 className="font-display text-4xl lg:text-6xl font-bold mb-6">
            Start Protecting
            <span className="shimmer-text block">Yourself Today</span>
          </h2>
          <p className="text-gray-400 text-lg mb-10 max-w-2xl mx-auto">
            Join thousands of users who trust FraudGuard to keep them safe. Free to start, no credit card required.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/signup" className="flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-violet-600 px-10 py-4 rounded-xl font-semibold text-lg hover:opacity-90 transition-opacity">
              Create Free Account <ArrowRight className="w-5 h-5"/>
            </Link>
            <Link to="/login" className="flex items-center justify-center border border-white/10 bg-white/5 px-10 py-4 rounded-xl font-medium text-lg hover:bg-white/10 transition-colors">
              Sign In
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/5 py-12 bg-[#050a18]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center">
                  <Shield className="w-4 h-4 text-white"/>
                </div>
                <span className="font-display font-bold">FraudGuard</span>
              </div>
              <p className="text-gray-500 text-sm">Enterprise-grade URL security for everyone.</p>
            </div>
            {[
              { title:'Product', links:['Features','Dashboard','Security','Pricing'] },
              { title:'Company', links:['About','Blog','Contact','Careers'] },
              { title:'Legal', links:['Privacy','Terms','Security','Cookies'] },
            ].map((col,i) => (
              <div key={i}>
                <h4 className="font-semibold text-sm mb-4">{col.title}</h4>
                <ul className="space-y-2">
                  {col.links.map(l => (
                    <li key={l}><a href="#" className="text-gray-500 hover:text-white text-sm transition-colors">{l}</a></li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-600 text-sm">© 2025 FraudGuard. All rights reserved.</p>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"/>
              <span className="text-gray-500 text-sm">All systems operational</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
