import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import {
  Shield, Search, LogOut, AlertTriangle, CheckCircle, XCircle,
  Clock, TrendingUp, Activity, BarChart2, Globe, Lock,
  RefreshCw, ChevronRight, Cpu, Database, Eye, Star
} from 'lucide-react'
import { scanAPI } from '../utils/api'

// Mini donut chart SVG
function DonutChart({ data, size = 120 }) {
  const total = data.reduce((s, d) => s + d.value, 0)
  if (total === 0) return (
    <div className="flex items-center justify-center" style={{ width: size, height: size }}>
      <span className="text-gray-600 text-xs">No data</span>
    </div>
  )
  let offset = 0
  const r = 45, cx = 60, cy = 60
  const circumference = 2 * Math.PI * r
  const segments = data.map(d => {
    const pct = d.value / total
    const seg = { ...d, pct, offset, stroke: circumference * pct, gap: circumference * (1 - pct) }
    offset += pct
    return seg
  })
  return (
    <svg width={size} height={size} viewBox="0 0 120 120">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#1a2035" strokeWidth="18"/>
      {segments.map((seg, i) => (
        <circle key={i} cx={cx} cy={cy} r={r} fill="none"
          stroke={seg.color} strokeWidth="18"
          strokeDasharray={`${seg.stroke} ${seg.gap}`}
          strokeDashoffset={-circumference * seg.offset}
          style={{ transform: 'rotate(-90deg)', transformOrigin: '60px 60px', transition: 'all 0.5s ease' }}
        />
      ))}
      <text x={cx} y={cy - 5} textAnchor="middle" fill="white" fontSize="18" fontWeight="bold" fontFamily="Syne,sans-serif">
        {total}
      </text>
      <text x={cx} y={cy + 14} textAnchor="middle" fill="#6b7280" fontSize="10">Scans</text>
    </svg>
  )
}

// Bar chart SVG
function BarChart({ data }) {
  const max = Math.max(...data.map(d => d.value), 1)
  return (
    <svg viewBox="0 0 280 120" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        {data.map((d, i) => (
          <linearGradient key={i} id={`bg${i}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={d.color} stopOpacity="0.9"/>
            <stop offset="100%" stopColor={d.color} stopOpacity="0.2"/>
          </linearGradient>
        ))}
      </defs>
      {[0,1,2,3].map(i => (
        <line key={i} x1="0" y1={10+i*25} x2="280" y2={10+i*25} stroke="rgba(255,255,255,0.04)" strokeWidth="1"/>
      ))}
      {data.map((d, i) => {
        const h = Math.max((d.value / max) * 85, 4)
        const x = 20 + i * (240 / data.length)
        return (
          <g key={i}>
            <rect x={x} y={100 - h} width="28" height={h} fill={`url(#bg${i})`} rx="4"
              style={{ animation: 'growBar 0.8s ease-out forwards', animationDelay: `${i * 0.1}s`, transformOrigin: 'bottom' }}/>
            <text x={x + 14} y="114" textAnchor="middle" fill={d.color} fontSize="9">{d.label}</text>
            {d.value > 0 && <text x={x + 14} y={95 - h} textAnchor="middle" fill="rgba(255,255,255,0.6)" fontSize="9">{d.value}</text>}
          </g>
        )
      })}
    </svg>
  )
}

// Risk meter gauge
function RiskGauge({ score }) {
  const angle = -135 + (score / 100) * 270
  const color = score >= 70 ? '#ef4444' : score >= 50 ? '#f97316' : score >= 30 ? '#eab308' : '#22c55e'
  return (
    <div className="relative flex items-center justify-center" style={{ width: 160, height: 100 }}>
      <svg viewBox="0 0 160 100" className="w-full h-full">
        <defs>
          <linearGradient id="gaugeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#22c55e"/>
            <stop offset="33%" stopColor="#eab308"/>
            <stop offset="66%" stopColor="#f97316"/>
            <stop offset="100%" stopColor="#ef4444"/>
          </linearGradient>
        </defs>
        <path d="M 20 80 A 60 60 0 0 1 140 80" fill="none" stroke="#1a2035" strokeWidth="12" strokeLinecap="round"/>
        <path d="M 20 80 A 60 60 0 0 1 140 80" fill="none" stroke="url(#gaugeGrad)" strokeWidth="12" strokeLinecap="round"
          strokeDasharray={`${score * 1.885} 188.5`}/>
        <g transform={`rotate(${angle}, 80, 80)`}>
          <line x1="80" y1="80" x2="80" y2="28" stroke={color} strokeWidth="2.5" strokeLinecap="round"/>
          <circle cx="80" cy="80" r="5" fill={color}/>
        </g>
        <text x="80" y="72" textAnchor="middle" fill="white" fontSize="22" fontWeight="bold" fontFamily="Syne">{score}</text>
        <text x="80" y="93" textAnchor="middle" fill="#6b7280" fontSize="10">Risk Score</text>
      </svg>
    </div>
  )
}

// Threat radar chart
function ThreatRadar({ threats }) {
  const categories = { 'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0, 'Info': 0 }
  threats.forEach(t => { if (categories[t.severity] !== undefined) categories[t.severity]++ })
  const points = Object.entries(categories)
  const cx = 80, cy = 80, r = 60
  const getCoords = (i, val, max = 5) => {
    const angle = (i / points.length) * 2 * Math.PI - Math.PI / 2
    const dist = (val / max) * r
    return { x: cx + dist * Math.cos(angle), y: cy + dist * Math.sin(angle) }
  }
  const polyPoints = points.map(([, v], i) => {
    const c = getCoords(i, Math.min(v, 5))
    return `${c.x},${c.y}`
  }).join(' ')
  return (
    <svg viewBox="0 0 160 160" className="w-full h-full">
      {[1,2,3,4,5].map(ring => (
        <polygon key={ring} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="1"
          points={points.map((_, i) => {
            const c = getCoords(i, ring)
            return `${c.x},${c.y}`
          }).join(' ')}
        />
      ))}
      {points.map((_, i) => {
        const end = getCoords(i, 5)
        return <line key={i} x1={cx} y1={cy} x2={end.x} y2={end.y} stroke="rgba(255,255,255,0.05)" strokeWidth="1"/>
      })}
      <polygon points={polyPoints} fill="rgba(139,92,246,0.2)" stroke="#8b5cf6" strokeWidth="1.5"/>
      {points.map(([label, val], i) => {
        const c = getCoords(i, 5.8)
        return <text key={i} x={c.x} y={c.y} textAnchor="middle" fill="#9ca3af" fontSize="9">{label} ({val})</text>
      })}
    </svg>
  )
}

// Severity badge
function SeverityBadge({ severity }) {
  const cfg = {
    Critical: 'bg-red-500/10 text-red-400 border-red-500/20',
    High: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
    Medium: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
    Low: 'bg-green-500/10 text-green-400 border-green-500/20',
    Info: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  }
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs border font-medium ${cfg[severity] || cfg.Info}`}>
      {severity}
    </span>
  )
}

// Risk Level badge
function RiskBadge({ level }) {
  const cfg = {
    Critical: 'bg-red-500/10 text-red-400 border-red-500/30',
    High: 'bg-orange-500/10 text-orange-400 border-orange-500/30',
    Medium: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
    Low: 'bg-green-500/10 text-green-400 border-green-500/30',
  }
  return (
    <span className={`px-3 py-1 rounded-full text-xs border font-bold ${cfg[level] || ''}`}>{level}</span>
  )
}

export default function Dashboard({ setAuth }) {
  const navigate = useNavigate()
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [scanResult, setScanResult] = useState(null)
  const [history, setHistory] = useState([])
  const [stats, setStats] = useState(null)
  const [user, setUser] = useState(null)
  const [activeTab, setActiveTab] = useState('scan')
  const [selectedScan, setSelectedScan] = useState(null)

  useEffect(() => {
    const u = localStorage.getItem('user')
    if (u) setUser(JSON.parse(u))
    fetchHistory(); fetchStats()
  }, [])

  const fetchHistory = async () => {
    try {
      const r = await scanAPI.getHistory({ limit: 20 })
      setHistory(r.data.scans || [])
    } catch {}
  }

  const fetchStats = async () => {
    try {
      const r = await scanAPI.getStats()
      setStats(r.data.stats)
    } catch {}
  }

  const handleScan = async (e) => {
    e.preventDefault()
    if (!url.trim()) return
    setLoading(true); setScanResult(null)
    try {
      const r = await scanAPI.scanURL(url)
      setScanResult(r.data.scan)
      setActiveTab('scan')
      fetchHistory(); fetchStats()
    } catch (err) {
      setScanResult({ error: true, message: err.response?.data?.error || 'Scan failed' })
    } finally { setLoading(false) }
  }

  const handleLogout = () => {
    localStorage.clear(); setAuth(false); navigate('/login')
  }

  const riskColor = (level) => ({
    Critical: '#ef4444', High: '#f97316', Medium: '#eab308', Low: '#22c55e'
  }[level] || '#6b7280')

  const donutData = stats ? [
    { label: 'Critical', value: stats.byRiskLevel?.Critical || 0, color: '#ef4444' },
    { label: 'High', value: stats.byRiskLevel?.High || 0, color: '#f97316' },
    { label: 'Medium', value: stats.byRiskLevel?.Medium || 0, color: '#eab308' },
    { label: 'Low', value: stats.byRiskLevel?.Low || 0, color: '#22c55e' },
  ] : []

  const barData = stats ? [
    { label: 'Critical', value: stats.byRiskLevel?.Critical || 0, color: '#ef4444' },
    { label: 'High', value: stats.byRiskLevel?.High || 0, color: '#f97316' },
    { label: 'Medium', value: stats.byRiskLevel?.Medium || 0, color: '#eab308' },
    { label: 'Low', value: stats.byRiskLevel?.Low || 0, color: '#22c55e' },
  ] : []

  const allThreats = scanResult && !scanResult.error ? (scanResult.threats || []) : []
  const realThreats = allThreats.filter(t => !['Info'].includes(t.severity) || t.type.includes('Blacklisted') || t.type.includes('Impersonation') || t.type.includes('Alert'))

  return (
    <div className="min-h-screen bg-[#050a18] text-white font-sans">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=Inter:wght@300;400;500;600&display=swap');
        * { font-family: 'Inter', sans-serif; }
        h1,h2,h3,.font-display { font-family: 'Syne', sans-serif; }
        @keyframes growBar { from{transform:scaleY(0);transform-origin:bottom} to{transform:scaleY(1)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
        .fade-in { animation: fadeIn 0.5s ease forwards; }
        .card { background: #0d1526; border: 1px solid rgba(255,255,255,0.06); border-radius: 16px; }
        .hover-card { transition: all 0.2s ease; }
        .hover-card:hover { border-color: rgba(59,130,246,0.3); transform: translateY(-2px); }
        ::-webkit-scrollbar { width: 4px; } ::-webkit-scrollbar-track { background: #050a18; } ::-webkit-scrollbar-thumb { background: #1e2d47; border-radius: 2px; }
      `}</style>

      {/* HEADER */}
      <header className="sticky top-0 z-40 bg-[#050a18]/90 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-white"/>
              </div>
              <span className="font-display font-bold text-lg">FraudGuard</span>
            </Link>
            <span className="text-gray-700">|</span>
            <span className="text-gray-400 text-sm">Dashboard</span>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-full px-3 py-1">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"/>
              <span className="text-green-400 text-xs">Systems Online</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <div className="text-sm font-medium">{user?.name}</div>
                <div className="text-xs text-gray-500">{user?.email}</div>
              </div>
              <button onClick={handleLogout} className="w-9 h-9 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center justify-center hover:bg-red-500/20 transition-colors">
                <LogOut className="w-4 h-4 text-red-400"/>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">

        {/* STATS ROW */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Scans', val: stats?.total || 0, icon: <Activity className="w-5 h-5"/>, color: 'blue', sub: 'All time' },
            { label: 'Critical', val: stats?.byRiskLevel?.Critical || 0, icon: <XCircle className="w-5 h-5"/>, color: 'red', sub: 'Blocked threats' },
            { label: 'High Risk', val: stats?.byRiskLevel?.High || 0, icon: <AlertTriangle className="w-5 h-5"/>, color: 'orange', sub: 'Dangerous URLs' },
            { label: 'Safe', val: stats?.byRiskLevel?.Low || 0, icon: <CheckCircle className="w-5 h-5"/>, color: 'green', sub: 'Clean URLs' },
          ].map((s, i) => (
            <div key={i} className={`card hover-card p-5`}>
              <div className="flex items-center justify-between mb-3">
                <span className="text-gray-500 text-sm">{s.label}</span>
                <div className={`text-${s.color}-400 bg-${s.color}-500/10 p-2 rounded-lg`}>{s.icon}</div>
              </div>
              <div className={`font-display text-3xl font-bold text-${s.color}-400`}>{s.val}</div>
              <div className="text-gray-600 text-xs mt-1">{s.sub}</div>
            </div>
          ))}
        </div>

        {/* MAIN LAYOUT */}
        <div className="grid lg:grid-cols-3 gap-6">

          {/* LEFT - Scanner + Results */}
          <div className="lg:col-span-2 space-y-6">

            {/* Scanner Input */}
            <div className="card p-6">
              <h2 className="font-display font-bold text-lg mb-4 flex items-center gap-2">
                <Search className="w-5 h-5 text-blue-400"/>
                URL Security Scanner
              </h2>
              <form onSubmit={handleScan} className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500"/>
                  <input
                    type="url" value={url} onChange={e => setUrl(e.target.value)}
                    placeholder="https://example.com"
                    className="w-full bg-[#0a1020] border border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-blue-500/50 placeholder-gray-600 transition-colors"
                    required
                  />
                </div>
                <button type="submit" disabled={loading}
                  className="flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-violet-600 px-6 py-3 rounded-xl font-medium text-sm hover:opacity-90 transition-opacity disabled:opacity-50 whitespace-nowrap">
                  {loading ? <><RefreshCw className="w-4 h-4 animate-spin"/> Scanning...</> : <><Search className="w-4 h-4"/> Scan URL</>}
                </button>
              </form>

              {/* Test examples */}
              <div className="mt-4 flex flex-wrap gap-2">
                <span className="text-xs text-gray-600">Try:</span>
                {['http://paypal-verify.tk/login', 'https://google.com'].map(ex => (
                  <button key={ex} onClick={() => setUrl(ex)}
                    className="text-xs text-blue-400/70 hover:text-blue-400 border border-blue-500/10 hover:border-blue-500/30 rounded-full px-3 py-1 transition-all truncate max-w-[200px]">
                    {ex}
                  </button>
                ))}
              </div>
            </div>

            {/* SCAN RESULTS */}
            {scanResult && (
              <div className="card p-6 fade-in">
                {scanResult.error ? (
                  <div className="flex items-center gap-3 text-red-400">
                    <XCircle className="w-6 h-6 flex-shrink-0"/>
                    <div>
                      <div className="font-semibold">Scan Failed</div>
                      <div className="text-sm text-gray-500">{scanResult.message}</div>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex items-start justify-between mb-6">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <RiskBadge level={scanResult.riskLevel}/>
                          <span className="text-gray-500 text-xs flex items-center gap-1">
                            <Clock className="w-3 h-3"/>
                            {new Date(scanResult.scanDate).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-gray-300 text-sm break-all">{scanResult.url}</p>
                      </div>
                    </div>

                    {/* Gauge + Threats Radar */}
                    <div className="grid sm:grid-cols-2 gap-6 mb-6">
                      <div className="bg-[#0a1020] rounded-xl p-4 flex flex-col items-center">
                        <div className="text-sm text-gray-500 mb-2">AI Risk Assessment</div>
                        <RiskGauge score={scanResult.riskScore}/>
                        <div className="mt-2 text-center">
                          <div className={`font-display font-bold text-lg`}
                            style={{ color: riskColor(scanResult.riskLevel) }}>
                            {scanResult.riskLevel} Risk
                          </div>
                        </div>
                      </div>

                      <div className="bg-[#0a1020] rounded-xl p-4 flex flex-col items-center">
                        <div className="text-sm text-gray-500 mb-2">Threat Radar</div>
                        <div className="w-full h-40">
                          <ThreatRadar threats={allThreats}/>
                        </div>
                      </div>
                    </div>

                    {/* Risk bar */}
                    <div className="mb-6">
                      <div className="flex justify-between text-xs text-gray-500 mb-2">
                        <span>Risk Score</span>
                        <span className="font-bold" style={{ color: riskColor(scanResult.riskLevel) }}>
                          {scanResult.riskScore}/100
                        </span>
                      </div>
                      <div className="w-full h-3 bg-[#0a1020] rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all duration-1000"
                          style={{
                            width: `${scanResult.riskScore}%`,
                            background: `linear-gradient(90deg, #22c55e, #eab308, #f97316, #ef4444)`,
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-gray-600 mt-1">
                        <span>Safe</span><span>Low</span><span>Medium</span><span>High</span><span>Critical</span>
                      </div>
                    </div>

                    {/* Threats list */}
                    <div>
                      <div className="text-sm font-semibold text-gray-300 mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-orange-400"/>
                        Detection Details ({allThreats.length} checks)
                      </div>
                      <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                        {allThreats.map((t, i) => (
                          <div key={i} className="flex items-start justify-between gap-3 bg-[#0a1020] rounded-lg p-3">
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium text-gray-200">{t.type}</div>
                              <div className="text-xs text-gray-500 mt-0.5 truncate">{t.description}</div>
                            </div>
                            <SeverityBadge severity={t.severity}/>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Scan History Table */}
            {history.length > 0 && (
              <div className="card p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-display font-bold text-base flex items-center gap-2">
                    <Clock className="w-4 h-4 text-violet-400"/> Recent Scans
                  </h3>
                  <span className="text-xs text-gray-500">{history.length} results</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left text-gray-600 border-b border-white/5">
                        <th className="pb-3 font-medium">URL</th>
                        <th className="pb-3 font-medium text-center">Score</th>
                        <th className="pb-3 font-medium text-center">Risk</th>
                        <th className="pb-3 font-medium text-center hidden sm:table-cell">Threats</th>
                        <th className="pb-3 font-medium text-right hidden sm:table-cell">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {history.map((s, i) => (
                        <tr key={i} className="hover:bg-white/2 transition-colors cursor-pointer group"
                          onClick={() => setSelectedScan(selectedScan?._id === s._id ? null : s)}>
                          <td className="py-3 pr-4">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full flex-shrink-0"
                                style={{ background: riskColor(s.riskLevel) }}/>
                              <span className="text-gray-300 truncate max-w-[180px] group-hover:text-white transition-colors">
                                {s.url}
                              </span>
                            </div>
                          </td>
                          <td className="py-3 text-center">
                            <span className="font-bold font-display" style={{ color: riskColor(s.riskLevel) }}>
                              {s.riskScore}
                            </span>
                          </td>
                          <td className="py-3 text-center"><RiskBadge level={s.riskLevel}/></td>
                          <td className="py-3 text-center text-gray-500 hidden sm:table-cell">{s.threats?.length || 0}</td>
                          <td className="py-3 text-right text-gray-500 hidden sm:table-cell text-xs">
                            {new Date(s.scanDate).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Expanded row detail */}
                {selectedScan && (
                  <div className="mt-4 bg-[#0a1020] rounded-xl p-4 fade-in border border-white/5">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-semibold text-gray-300">Scan Details</span>
                      <button onClick={() => setSelectedScan(null)} className="text-gray-600 hover:text-white text-xs">✕ close</button>
                    </div>
                    <p className="text-blue-400 text-xs break-all mb-3">{selectedScan.url}</p>
                    <div className="grid grid-cols-3 gap-3 mb-3">
                      <div className="text-center">
                        <div className="font-display font-bold text-xl" style={{ color: riskColor(selectedScan.riskLevel) }}>{selectedScan.riskScore}</div>
                        <div className="text-xs text-gray-600">Score</div>
                      </div>
                      <div className="text-center">
                        <div className="font-display font-bold text-xl text-orange-400">{selectedScan.threats?.length || 0}</div>
                        <div className="text-xs text-gray-600">Checks</div>
                      </div>
                      <div className="text-center">
                        <RiskBadge level={selectedScan.riskLevel}/>
                      </div>
                    </div>
                    <div className="space-y-1.5 max-h-40 overflow-y-auto">
                      {(selectedScan.threats || []).slice(0, 8).map((t, i) => (
                        <div key={i} className="flex justify-between items-center gap-2">
                          <span className="text-xs text-gray-400 truncate">{t.type}</span>
                          <SeverityBadge severity={t.severity}/>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* RIGHT - Charts & Analytics */}
          <div className="space-y-6">

            {/* Donut chart */}
            <div className="card p-6">
              <h3 className="font-display font-bold text-base mb-4 flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-blue-400"/> Scan Distribution
              </h3>
              {stats && stats.total > 0 ? (
                <>
                  <div className="flex items-center justify-center mb-4">
                    <DonutChart data={donutData} size={130}/>
                  </div>
                  <div className="space-y-2">
                    {donutData.map((d, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: d.color }}/>
                          <span className="text-gray-400 text-sm">{d.label}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm" style={{ color: d.color }}>{d.value}</span>
                          <span className="text-gray-600 text-xs">{stats.total > 0 ? Math.round(d.value / stats.total * 100) : 0}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-gray-600">
                  <BarChart2 className="w-10 h-10 mx-auto mb-2 opacity-30"/>
                  <p className="text-sm">No scan data yet</p>
                  <p className="text-xs mt-1">Start scanning URLs to see analytics</p>
                </div>
              )}
            </div>

            {/* Bar chart */}
            <div className="card p-6">
              <h3 className="font-display font-bold text-base mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-violet-400"/> Risk Breakdown
              </h3>
              {stats && stats.total > 0 ? (
                <div className="h-32">
                  <BarChart data={barData}/>
                </div>
              ) : (
                <div className="text-center py-6 text-gray-600 text-sm">No data yet</div>
              )}
            </div>

            {/* Detection Methods */}
            <div className="card p-6">
              <h3 className="font-display font-bold text-base mb-4 flex items-center gap-2">
                <Cpu className="w-4 h-4 text-cyan-400"/> Detection Methods
              </h3>
              <div className="space-y-3">
                {[
                  { name: 'Google Safe Browsing', icon: <Globe className="w-3.5 h-3.5"/>, status: process.env.GOOGLE_SAFE_BROWSING_API_KEY ? 'active' : 'passive', pct: 95 },
                  { name: 'ML Model', icon: <Cpu className="w-3.5 h-3.5"/>, status: 'active', pct: 90 },
                  { name: 'SSL Validation', icon: <Lock className="w-3.5 h-3.5"/>, status: 'active', pct: 100 },
                  { name: 'Blacklist Check', icon: <Database className="w-3.5 h-3.5"/>, status: 'active', pct: 85 },
                  { name: 'Content Analysis', icon: <Eye className="w-3.5 h-3.5"/>, status: 'active', pct: 80 },
                  { name: 'Pattern Heuristics', icon: <Activity className="w-3.5 h-3.5"/>, status: 'active', pct: 100 },
                ].map((m, i) => (
                  <div key={i}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2 text-gray-400 text-xs">
                        <span className="text-blue-400">{m.icon}</span>
                        {m.name}
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${m.status === 'active' ? 'bg-green-500/10 text-green-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                        {m.status}
                      </span>
                    </div>
                    <div className="h-1.5 bg-[#0a1020] rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-gradient-to-r from-blue-600 to-violet-600"
                        style={{ width: `${m.pct}%`, transition: 'width 1s ease' }}/>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Security Tips */}
            <div className="card p-6">
              <h3 className="font-display font-bold text-base mb-4 flex items-center gap-2">
                <Star className="w-4 h-4 text-amber-400"/> Security Tips
              </h3>
              <div className="space-y-3">
                {[
                  'Always check for HTTPS before entering passwords',
                  'Verify domain name carefully — one typo can redirect to a phishing site',
                  'Hover over links before clicking to see the real URL',
                  'Use FraudGuard to scan links before visiting suspicious sites',
                ].map((tip, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-gray-500">
                    <ChevronRight className="w-3 h-3 text-blue-500 mt-0.5 flex-shrink-0"/>
                    {tip}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
