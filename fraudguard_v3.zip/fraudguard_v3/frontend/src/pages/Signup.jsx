import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Shield, Mail, Lock, User, AlertCircle, ArrowRight, CheckCircle } from 'lucide-react'
import { authAPI } from '../utils/api'

export default function Signup({ setAuth }) {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (formData.password.length < 6) { setError('Password must be at least 6 characters'); return }
    setLoading(true); setError('')
    try {
      const response = await authAPI.signup(formData)
      localStorage.setItem('token', response.data.token)
      localStorage.setItem('user', JSON.stringify(response.data.user))
      setAuth(true)
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.error || 'Signup failed. Please try again.')
    } finally { setLoading(false) }
  }

  const strength = formData.password.length === 0 ? 0 : formData.password.length < 6 ? 1 : formData.password.length < 10 ? 2 : 3
  const strengthLabel = ['', 'Weak', 'Good', 'Strong']
  const strengthColor = ['', '#ef4444', '#eab308', '#22c55e']

  return (
    <div className="min-h-screen bg-[#050a18] text-white flex items-center justify-center p-4">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=Inter:wght@300;400;500;600&display=swap');
        * { font-family:'Inter',sans-serif; } .font-display{font-family:'Syne',sans-serif;}
      `}</style>
      <div className="fixed top-1/4 right-1/4 w-96 h-96 bg-violet-600/5 rounded-full blur-[120px] pointer-events-none"/>
      <div className="fixed bottom-1/4 left-1/4 w-96 h-96 bg-blue-600/5 rounded-full blur-[120px] pointer-events-none"/>

      <div className="w-full max-w-md relative">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-violet-600 rounded-xl flex items-center justify-center">
              <Shield className="w-7 h-7 text-white"/>
            </div>
            <span className="font-display font-bold text-2xl">FraudGuard</span>
          </Link>
          <h1 className="font-display text-3xl font-bold mb-2">Create account</h1>
          <p className="text-gray-500 text-sm">Start protecting yourself from cyber threats</p>
        </div>

        <div className="bg-[#0d1526] border border-white/6 rounded-2xl p-8">
          {error && (
            <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0"/>
              <span className="text-red-400 text-sm">{error}</span>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Full Name</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600"/>
                <input type="text" name="name" value={formData.name} onChange={handleChange}
                  className="w-full bg-[#0a1020] border border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-blue-500/50 placeholder-gray-700 transition-colors"
                  placeholder="Your full name" required/>
              </div>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600"/>
                <input type="email" name="email" value={formData.email} onChange={handleChange}
                  className="w-full bg-[#0a1020] border border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-blue-500/50 placeholder-gray-700 transition-colors"
                  placeholder="your@email.com" required/>
              </div>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600"/>
                <input type="password" name="password" value={formData.password} onChange={handleChange}
                  className="w-full bg-[#0a1020] border border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-blue-500/50 placeholder-gray-700 transition-colors"
                  placeholder="Min. 6 characters" required/>
              </div>
              {formData.password.length > 0 && (
                <div className="mt-2">
                  <div className="flex gap-1 mb-1">
                    {[1,2,3].map(i => (
                      <div key={i} className="flex-1 h-1 rounded-full transition-all duration-300"
                        style={{ background: i <= strength ? strengthColor[strength] : '#1a2035' }}/>
                    ))}
                  </div>
                  <span className="text-xs" style={{ color: strengthColor[strength] }}>{strengthLabel[strength]} password</span>
                </div>
              )}
            </div>
            <button type="submit" disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-violet-600 py-3.5 rounded-xl font-semibold hover:opacity-90 transition-opacity disabled:opacity-50">
              {loading ? 'Creating account...' : <><span>Create Account</span><ArrowRight className="w-4 h-4"/></>}
            </button>
          </form>
          <p className="mt-6 text-center text-gray-600 text-sm">
            Already have an account?{' '}
            <Link to="/login" className="text-blue-400 hover:text-blue-300 transition-colors font-medium">Sign in</Link>
          </p>
        </div>

        <div className="mt-6 grid grid-cols-3 gap-3 text-center">
          {['Free forever','Instant access','No credit card'].map((t,i) => (
            <div key={i} className="flex items-center justify-center gap-1.5 text-xs text-gray-600">
              <CheckCircle className="w-3 h-3 text-green-500"/> {t}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
