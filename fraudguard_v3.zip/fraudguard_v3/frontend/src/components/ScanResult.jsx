import { AlertTriangle, CheckCircle, XCircle, Shield, Clock } from 'lucide-react'

export default function ScanResult({ result }) {
  if (result.error) {
    return (
      <div className="card mb-8 border-2 border-red-200">
        <div className="flex items-center gap-3 text-red-600">
          <XCircle className="w-8 h-8" />
          <div>
            <h3 className="font-bold text-lg">Scan Failed</h3>
            <p>{result.message}</p>
          </div>
        </div>
      </div>
    )
  }

  const getRiskIcon = () => {
    switch(result.riskLevel) {
      case 'Critical':
      case 'High':
        return <XCircle className="w-12 h-12 text-red-600" />
      case 'Medium':
        return <AlertTriangle className="w-12 h-12 text-yellow-600" />
      case 'Low':
        return <CheckCircle className="w-12 h-12 text-green-600" />
      default:
        return <Shield className="w-12 h-12 text-gray-600" />
    }
  }

  const getRiskColor = () => {
    switch(result.riskLevel) {
      case 'Critical': return 'border-red-500 bg-red-50'
      case 'High': return 'border-orange-500 bg-orange-50'
      case 'Medium': return 'border-yellow-500 bg-yellow-50'
      case 'Low': return 'border-green-500 bg-green-50'
      default: return 'border-gray-500 bg-gray-50'
    }
  }

  const getScoreColor = () => {
    if (result.riskScore >= 70) return 'text-red-600'
    if (result.riskScore >= 50) return 'text-orange-600'
    if (result.riskScore >= 30) return 'text-yellow-600'
    return 'text-green-600'
  }

  return (
    <div className={`card mb-8 border-2 ${getRiskColor()}`}>
      <div className="flex items-start gap-4 mb-6">
        <div>{getRiskIcon()}</div>
        <div className="flex-1">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">
            Scan Complete - {result.riskLevel} Risk
          </h3>
          <p className="text-gray-600 break-all">{result.url}</p>
          <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
            <Clock className="w-4 h-4" />
            <span>{new Date(result.scanDate).toLocaleString()}</span>
          </div>
        </div>
        <div className="text-center">
          <div className={`text-5xl font-bold ${getScoreColor()}`}>
            {result.riskScore}
          </div>
          <div className="text-sm text-gray-600 mt-1">Risk Score</div>
        </div>
      </div>

      {/* Risk Score Bar */}
      <div className="mb-6">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-gray-600">Risk Level</span>
          <span className="font-medium">{result.riskScore}/100</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-3">
          <div
            className={`h-3 rounded-full transition-all ${
              result.riskScore >= 70 ? 'bg-red-600' :
              result.riskScore >= 50 ? 'bg-orange-600' :
              result.riskScore >= 30 ? 'bg-yellow-600' : 'bg-green-600'
            }`}
            style={{ width: `${result.riskScore}%` }}
          />
        </div>
      </div>

      {/* Threats Detected */}
      {result.threats && result.threats.length > 0 && (
        <div>
          <h4 className="font-bold text-lg text-gray-900 mb-3">
            Threats Detected ({result.threats.length})
          </h4>
          <div className="space-y-3">
            {result.threats.map((threat, index) => (
              <div
                key={index}
                className="bg-white border border-gray-200 rounded-lg p-4"
              >
                <div className="flex items-start justify-between mb-2">
                  <h5 className="font-semibold text-gray-900">{threat.type}</h5>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      threat.severity === 'Critical' ? 'bg-red-100 text-red-700' :
                      threat.severity === 'High' ? 'bg-orange-100 text-orange-700' :
                      threat.severity === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-green-100 text-green-700'
                    }`}
                  >
                    {threat.severity}
                  </span>
                </div>
                <p className="text-gray-600 text-sm">{threat.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {result.threats && result.threats.length === 0 && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
          <CheckCircle className="w-6 h-6 text-green-600" />
          <div>
            <h5 className="font-semibold text-green-900">No Threats Detected</h5>
            <p className="text-green-700 text-sm">This URL appears to be safe based on our analysis.</p>
          </div>
        </div>
      )}
    </div>
  )
}
