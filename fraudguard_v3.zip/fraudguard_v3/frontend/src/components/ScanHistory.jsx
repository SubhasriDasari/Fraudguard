import { History, ExternalLink } from 'lucide-react'

export default function ScanHistory({ history, getRiskColor }) {
  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-4">
        <History className="w-6 h-6 text-gray-700" />
        <h2 className="text-xl font-bold text-gray-900">Recent Scans</h2>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-3 px-2 text-sm font-semibold text-gray-700">URL</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-700">Risk Score</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-700">Risk Level</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-700">Threats</th>
              <th className="text-right py-3 px-2 text-sm font-semibold text-gray-700">Date</th>
            </tr>
          </thead>
          <tbody>
            {history.map((scan) => (
              <tr key={scan._id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-3 px-2">
                  <div className="flex items-center gap-2">
                    <a
                      href={scan.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline text-sm max-w-xs truncate block"
                    >
                      {scan.url}
                    </a>
                    <ExternalLink className="w-3 h-3 text-gray-400" />
                  </div>
                </td>
                <td className="py-3 px-2 text-center">
                  <span className={`font-bold ${
                    scan.riskScore >= 70 ? 'text-red-600' :
                    scan.riskScore >= 50 ? 'text-orange-600' :
                    scan.riskScore >= 30 ? 'text-yellow-600' : 'text-green-600'
                  }`}>
                    {scan.riskScore}
                  </span>
                </td>
                <td className="py-3 px-2 text-center">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getRiskColor(scan.riskLevel)}`}>
                    {scan.riskLevel}
                  </span>
                </td>
                <td className="py-3 px-2 text-center text-sm text-gray-600">
                  {scan.threats?.length || 0}
                </td>
                <td className="py-3 px-2 text-right text-sm text-gray-600">
                  {new Date(scan.scanDate).toLocaleDateString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
